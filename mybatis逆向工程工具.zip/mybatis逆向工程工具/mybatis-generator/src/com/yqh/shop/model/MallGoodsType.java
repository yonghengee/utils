package com.yqh.shop.model;

import java.util.Date;

public class MallGoodsType {

    private Integer goods_type_id;
    private Integer p_goods_type_id;
    private String type_name;
    private String code;
    private Integer level;
    private Integer curr_sort;
    private Integer sort;
    private String described;
    private Integer display;
    private String keyword;
    private Integer product_num;
    private Integer type;
    private Integer is_real;
    private Integer status;
    private String file_id;
    private String path;
    private Date create_time;
    private Date modify_time;

    public Integer getGoods_type_id() {
        return goods_type_id;
    }
    public void setGoods_type_id(Integer goods_type_id) {
        this.goods_type_id = goods_type_id;
    }
    public Integer getP_goods_type_id() {
        return p_goods_type_id;
    }
    public void setP_goods_type_id(Integer p_goods_type_id) {
        this.p_goods_type_id = p_goods_type_id;
    }
    public String getType_name() {
        return type_name;
    }
    public void setType_name(String type_name) {
        this.type_name = type_name == null ? null : type_name.trim();
    }
    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }
    public Integer getLevel() {
        return level;
    }
    public void setLevel(Integer level) {
        this.level = level;
    }
    public Integer getCurr_sort() {
        return curr_sort;
    }
    public void setCurr_sort(Integer curr_sort) {
        this.curr_sort = curr_sort;
    }
    public Integer getSort() {
        return sort;
    }
    public void setSort(Integer sort) {
        this.sort = sort;
    }
    public String getDescribed() {
        return described;
    }
    public void setDescribed(String described) {
        this.described = described == null ? null : described.trim();
    }
    public Integer getDisplay() {
        return display;
    }
    public void setDisplay(Integer display) {
        this.display = display;
    }
    public String getKeyword() {
        return keyword;
    }
    public void setKeyword(String keyword) {
        this.keyword = keyword == null ? null : keyword.trim();
    }
    public Integer getProduct_num() {
        return product_num;
    }
    public void setProduct_num(Integer product_num) {
        this.product_num = product_num;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Integer getIs_real() {
        return is_real;
    }
    public void setIs_real(Integer is_real) {
        this.is_real = is_real;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public String getFile_id() {
        return file_id;
    }
    public void setFile_id(String file_id) {
        this.file_id = file_id == null ? null : file_id.trim();
    }
    public String getPath() {
        return path;
    }
    public void setPath(String path) {
        this.path = path == null ? null : path.trim();
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}