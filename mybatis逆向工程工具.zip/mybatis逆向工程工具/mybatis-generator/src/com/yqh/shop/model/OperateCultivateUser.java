package com.yqh.shop.model;

import java.util.Date;

public class OperateCultivateUser {

    private String cultivate_user_id;
    private String cultivate_id;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getCultivate_user_id() {
        return cultivate_user_id;
    }
    public void setCultivate_user_id(String cultivate_user_id) {
        this.cultivate_user_id = cultivate_user_id == null ? null : cultivate_user_id.trim();
    }
    public String getCultivate_id() {
        return cultivate_id;
    }
    public void setCultivate_id(String cultivate_id) {
        this.cultivate_id = cultivate_id == null ? null : cultivate_id.trim();
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}