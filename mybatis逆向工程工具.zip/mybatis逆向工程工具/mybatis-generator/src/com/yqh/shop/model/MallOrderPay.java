package com.yqh.shop.model;

import java.math.BigDecimal;
import java.util.Date;

public class MallOrderPay {

    private String order_pay_id;
    private String user_id;
    private String sn;
    private BigDecimal money;
    private Integer trade_mode;
    private String trade_code;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getOrder_pay_id() {
        return order_pay_id;
    }
    public void setOrder_pay_id(String order_pay_id) {
        this.order_pay_id = order_pay_id == null ? null : order_pay_id.trim();
    }
    public String getUser_id() {
        return user_id;
    }
    public void setUser_id(String user_id) {
        this.user_id = user_id == null ? null : user_id.trim();
    }
    public String getSn() {
        return sn;
    }
    public void setSn(String sn) {
        this.sn = sn == null ? null : sn.trim();
    }
    public BigDecimal getMoney() {
        return money;
    }
    public void setMoney(BigDecimal money) {
        this.money = money;
    }
    public Integer getTrade_mode() {
        return trade_mode;
    }
    public void setTrade_mode(Integer trade_mode) {
        this.trade_mode = trade_mode;
    }
    public String getTrade_code() {
        return trade_code;
    }
    public void setTrade_code(String trade_code) {
        this.trade_code = trade_code == null ? null : trade_code.trim();
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}