package com.yqh.shop.model;

import java.util.Date;

public class SysAdminMessageRegion {

    private String message_region_id;
    private String message_id;
    private String region_id;
    private String region_name;
    private Integer level;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getMessage_region_id() {
        return message_region_id;
    }
    public void setMessage_region_id(String message_region_id) {
        this.message_region_id = message_region_id == null ? null : message_region_id.trim();
    }
    public String getMessage_id() {
        return message_id;
    }
    public void setMessage_id(String message_id) {
        this.message_id = message_id == null ? null : message_id.trim();
    }
    public String getRegion_id() {
        return region_id;
    }
    public void setRegion_id(String region_id) {
        this.region_id = region_id == null ? null : region_id.trim();
    }
    public String getRegion_name() {
        return region_name;
    }
    public void setRegion_name(String region_name) {
        this.region_name = region_name == null ? null : region_name.trim();
    }
    public Integer getLevel() {
        return level;
    }
    public void setLevel(Integer level) {
        this.level = level;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}