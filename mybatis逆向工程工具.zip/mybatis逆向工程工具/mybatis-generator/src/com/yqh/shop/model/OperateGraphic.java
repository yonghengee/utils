package com.yqh.shop.model;

import java.util.Date;

public class OperateGraphic {

    private String graphic_id;
    private String message_id;
    private Integer message_type;
    private String title;
    private String path;
    private String described;
    private Integer points;
    private Integer total_num;
    private Integer used_num;
    private Integer see_count;
    private Integer spot_laud;
    private Integer enables;
    private Integer status;
    private Integer activity_status;
    private Date create_time;
    private Date modify_time;
    private String content;

    public String getGraphic_id() {
        return graphic_id;
    }
    public void setGraphic_id(String graphic_id) {
        this.graphic_id = graphic_id == null ? null : graphic_id.trim();
    }
    public String getMessage_id() {
        return message_id;
    }
    public void setMessage_id(String message_id) {
        this.message_id = message_id == null ? null : message_id.trim();
    }
    public Integer getMessage_type() {
        return message_type;
    }
    public void setMessage_type(Integer message_type) {
        this.message_type = message_type;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }
    public String getPath() {
        return path;
    }
    public void setPath(String path) {
        this.path = path == null ? null : path.trim();
    }
    public String getDescribed() {
        return described;
    }
    public void setDescribed(String described) {
        this.described = described == null ? null : described.trim();
    }
    public Integer getPoints() {
        return points;
    }
    public void setPoints(Integer points) {
        this.points = points;
    }
    public Integer getTotal_num() {
        return total_num;
    }
    public void setTotal_num(Integer total_num) {
        this.total_num = total_num;
    }
    public Integer getUsed_num() {
        return used_num;
    }
    public void setUsed_num(Integer used_num) {
        this.used_num = used_num;
    }
    public Integer getSee_count() {
        return see_count;
    }
    public void setSee_count(Integer see_count) {
        this.see_count = see_count;
    }
    public Integer getSpot_laud() {
        return spot_laud;
    }
    public void setSpot_laud(Integer spot_laud) {
        this.spot_laud = spot_laud;
    }
    public Integer getEnables() {
        return enables;
    }
    public void setEnables(Integer enables) {
        this.enables = enables;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getActivity_status() {
        return activity_status;
    }
    public void setActivity_status(Integer activity_status) {
        this.activity_status = activity_status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }
}