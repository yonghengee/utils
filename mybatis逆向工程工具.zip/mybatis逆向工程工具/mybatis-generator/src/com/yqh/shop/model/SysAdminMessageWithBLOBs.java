package com.yqh.shop.model;

public class SysAdminMessageWithBLOBs extends SysAdminMessage {

    private String open_account_process;
    private String after_sale;

    public String getOpen_account_process() {
        return open_account_process;
    }
    public void setOpen_account_process(String open_account_process) {
        this.open_account_process = open_account_process == null ? null : open_account_process.trim();
    }
    public String getAfter_sale() {
        return after_sale;
    }
    public void setAfter_sale(String after_sale) {
        this.after_sale = after_sale == null ? null : after_sale.trim();
    }
}