package com.yqh.shop.model;

import java.util.Date;

public class SysFile {

    private String file_id;
    private String user_id;
    private String path;
    private String url;
    private String name;
    private String suffix;
    private Date create_time;
    private Date modify_time;

    public String getFile_id() {
        return file_id;
    }
    public void setFile_id(String file_id) {
        this.file_id = file_id == null ? null : file_id.trim();
    }
    public String getUser_id() {
        return user_id;
    }
    public void setUser_id(String user_id) {
        this.user_id = user_id == null ? null : user_id.trim();
    }
    public String getPath() {
        return path;
    }
    public void setPath(String path) {
        this.path = path == null ? null : path.trim();
    }
    public String getUrl() {
        return url;
    }
    public void setUrl(String url) {
        this.url = url == null ? null : url.trim();
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }
    public String getSuffix() {
        return suffix;
    }
    public void setSuffix(String suffix) {
        this.suffix = suffix == null ? null : suffix.trim();
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}