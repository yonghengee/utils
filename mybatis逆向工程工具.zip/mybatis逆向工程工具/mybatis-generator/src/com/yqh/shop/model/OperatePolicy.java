package com.yqh.shop.model;

import java.util.Date;

public class OperatePolicy {

    private String policy_id;
    private String message_id;
    private String title;
    private Integer used_points;
    private Integer total_points;
    private Integer sort;
    private Integer see_count;
    private Integer apply_num;
    private Integer adopt_num;
    private Integer finish_num;
    private Date start_time;
    private Date end_time;
    private Integer type;
    private Integer status;
    private Integer enables;
    private Integer activity_status;
    private Integer top_enables;
    private Date top_start_time;
    private Date top_end_time;
    private String remark;
    private Date create_time;
    private Date midify_time;
    private String described;

    public String getPolicy_id() {
        return policy_id;
    }
    public void setPolicy_id(String policy_id) {
        this.policy_id = policy_id == null ? null : policy_id.trim();
    }
    public String getMessage_id() {
        return message_id;
    }
    public void setMessage_id(String message_id) {
        this.message_id = message_id == null ? null : message_id.trim();
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }
    public Integer getUsed_points() {
        return used_points;
    }
    public void setUsed_points(Integer used_points) {
        this.used_points = used_points;
    }
    public Integer getTotal_points() {
        return total_points;
    }
    public void setTotal_points(Integer total_points) {
        this.total_points = total_points;
    }
    public Integer getSort() {
        return sort;
    }
    public void setSort(Integer sort) {
        this.sort = sort;
    }
    public Integer getSee_count() {
        return see_count;
    }
    public void setSee_count(Integer see_count) {
        this.see_count = see_count;
    }
    public Integer getApply_num() {
        return apply_num;
    }
    public void setApply_num(Integer apply_num) {
        this.apply_num = apply_num;
    }
    public Integer getAdopt_num() {
        return adopt_num;
    }
    public void setAdopt_num(Integer adopt_num) {
        this.adopt_num = adopt_num;
    }
    public Integer getFinish_num() {
        return finish_num;
    }
    public void setFinish_num(Integer finish_num) {
        this.finish_num = finish_num;
    }
    public Date getStart_time() {
        return start_time;
    }
    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }
    public Date getEnd_time() {
        return end_time;
    }
    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getEnables() {
        return enables;
    }
    public void setEnables(Integer enables) {
        this.enables = enables;
    }
    public Integer getActivity_status() {
        return activity_status;
    }
    public void setActivity_status(Integer activity_status) {
        this.activity_status = activity_status;
    }
    public Integer getTop_enables() {
        return top_enables;
    }
    public void setTop_enables(Integer top_enables) {
        this.top_enables = top_enables;
    }
    public Date getTop_start_time() {
        return top_start_time;
    }
    public void setTop_start_time(Date top_start_time) {
        this.top_start_time = top_start_time;
    }
    public Date getTop_end_time() {
        return top_end_time;
    }
    public void setTop_end_time(Date top_end_time) {
        this.top_end_time = top_end_time;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getMidify_time() {
        return midify_time;
    }
    public void setMidify_time(Date midify_time) {
        this.midify_time = midify_time;
    }
    public String getDescribed() {
        return described;
    }
    public void setDescribed(String described) {
        this.described = described == null ? null : described.trim();
    }
}