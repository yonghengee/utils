package com.yqh.shop.model;

import java.math.BigDecimal;
import java.util.Date;

public class MallOrderPayDetails {

    private String order_pay_details_id;
    private String order_id;
    private String order_pay_id;
    private BigDecimal money;
    private Date create_time;
    private Date modify_time;

    public String getOrder_pay_details_id() {
        return order_pay_details_id;
    }
    public void setOrder_pay_details_id(String order_pay_details_id) {
        this.order_pay_details_id = order_pay_details_id == null ? null : order_pay_details_id.trim();
    }
    public String getOrder_id() {
        return order_id;
    }
    public void setOrder_id(String order_id) {
        this.order_id = order_id == null ? null : order_id.trim();
    }
    public String getOrder_pay_id() {
        return order_pay_id;
    }
    public void setOrder_pay_id(String order_pay_id) {
        this.order_pay_id = order_pay_id == null ? null : order_pay_id.trim();
    }
    public BigDecimal getMoney() {
        return money;
    }
    public void setMoney(BigDecimal money) {
        this.money = money;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}