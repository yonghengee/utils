package com.yqh.shop.model;

import java.math.BigDecimal;
import java.util.Date;

public class MallGoods {

    private String goods_id;
    private Integer goods_type_id;
    private String message_id;
    private Integer message_type;
    private String sn;
    private String goods_name;
    private String vender_name;
    private String producer;
    private String described;
    private Integer sales_volume;
    private Integer inventory;
    private BigDecimal freight_price;
    private String original_price;
    private String sale_price;
    private String outer_code;
    private Integer sort;
    private Integer points;
    private Integer see_count;
    private Integer collect_count;
    private Integer type;
    private Integer is_real;
    private Integer on_sale;
    private Integer status;
    private Integer is_member;
    private Integer goods_type;
    private String bar_code;
    private String batch_code;
    private String approval_code;
    private Integer dosage_form;
    private Date create_time;
    private Date modify_time;
    private String quote_goods_id;
    private String quote_message_id;
    private String instruction;

    public String getGoods_id() {
        return goods_id;
    }
    public void setGoods_id(String goods_id) {
        this.goods_id = goods_id == null ? null : goods_id.trim();
    }
    public Integer getGoods_type_id() {
        return goods_type_id;
    }
    public void setGoods_type_id(Integer goods_type_id) {
        this.goods_type_id = goods_type_id;
    }
    public String getMessage_id() {
        return message_id;
    }
    public void setMessage_id(String message_id) {
        this.message_id = message_id == null ? null : message_id.trim();
    }
    public Integer getMessage_type() {
        return message_type;
    }
    public void setMessage_type(Integer message_type) {
        this.message_type = message_type;
    }
    public String getSn() {
        return sn;
    }
    public void setSn(String sn) {
        this.sn = sn == null ? null : sn.trim();
    }
    public String getGoods_name() {
        return goods_name;
    }
    public void setGoods_name(String goods_name) {
        this.goods_name = goods_name == null ? null : goods_name.trim();
    }
    public String getVender_name() {
        return vender_name;
    }
    public void setVender_name(String vender_name) {
        this.vender_name = vender_name == null ? null : vender_name.trim();
    }
    public String getProducer() {
        return producer;
    }
    public void setProducer(String producer) {
        this.producer = producer == null ? null : producer.trim();
    }
    public String getDescribed() {
        return described;
    }
    public void setDescribed(String described) {
        this.described = described == null ? null : described.trim();
    }
    public Integer getSales_volume() {
        return sales_volume;
    }
    public void setSales_volume(Integer sales_volume) {
        this.sales_volume = sales_volume;
    }
    public Integer getInventory() {
        return inventory;
    }
    public void setInventory(Integer inventory) {
        this.inventory = inventory;
    }
    public BigDecimal getFreight_price() {
        return freight_price;
    }
    public void setFreight_price(BigDecimal freight_price) {
        this.freight_price = freight_price;
    }
    public String getOriginal_price() {
        return original_price;
    }
    public void setOriginal_price(String original_price) {
        this.original_price = original_price == null ? null : original_price.trim();
    }
    public String getSale_price() {
        return sale_price;
    }
    public void setSale_price(String sale_price) {
        this.sale_price = sale_price == null ? null : sale_price.trim();
    }
    public String getOuter_code() {
        return outer_code;
    }
    public void setOuter_code(String outer_code) {
        this.outer_code = outer_code == null ? null : outer_code.trim();
    }
    public Integer getSort() {
        return sort;
    }
    public void setSort(Integer sort) {
        this.sort = sort;
    }
    public Integer getPoints() {
        return points;
    }
    public void setPoints(Integer points) {
        this.points = points;
    }
    public Integer getSee_count() {
        return see_count;
    }
    public void setSee_count(Integer see_count) {
        this.see_count = see_count;
    }
    public Integer getCollect_count() {
        return collect_count;
    }
    public void setCollect_count(Integer collect_count) {
        this.collect_count = collect_count;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Integer getIs_real() {
        return is_real;
    }
    public void setIs_real(Integer is_real) {
        this.is_real = is_real;
    }
    public Integer getOn_sale() {
        return on_sale;
    }
    public void setOn_sale(Integer on_sale) {
        this.on_sale = on_sale;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getIs_member() {
        return is_member;
    }
    public void setIs_member(Integer is_member) {
        this.is_member = is_member;
    }
    public Integer getGoods_type() {
        return goods_type;
    }
    public void setGoods_type(Integer goods_type) {
        this.goods_type = goods_type;
    }
    public String getBar_code() {
        return bar_code;
    }
    public void setBar_code(String bar_code) {
        this.bar_code = bar_code == null ? null : bar_code.trim();
    }
    public String getBatch_code() {
        return batch_code;
    }
    public void setBatch_code(String batch_code) {
        this.batch_code = batch_code == null ? null : batch_code.trim();
    }
    public String getApproval_code() {
        return approval_code;
    }
    public void setApproval_code(String approval_code) {
        this.approval_code = approval_code == null ? null : approval_code.trim();
    }
    public Integer getDosage_form() {
        return dosage_form;
    }
    public void setDosage_form(Integer dosage_form) {
        this.dosage_form = dosage_form;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
    public String getQuote_goods_id() {
        return quote_goods_id;
    }
    public void setQuote_goods_id(String quote_goods_id) {
        this.quote_goods_id = quote_goods_id == null ? null : quote_goods_id.trim();
    }
    public String getQuote_message_id() {
        return quote_message_id;
    }
    public void setQuote_message_id(String quote_message_id) {
        this.quote_message_id = quote_message_id == null ? null : quote_message_id.trim();
    }
    public String getInstruction() {
        return instruction;
    }
    public void setInstruction(String instruction) {
        this.instruction = instruction == null ? null : instruction.trim();
    }
}