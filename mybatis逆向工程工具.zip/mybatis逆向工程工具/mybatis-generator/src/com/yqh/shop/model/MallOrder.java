package com.yqh.shop.model;

import java.math.BigDecimal;
import java.util.Date;

public class MallOrder {

    private String order_id;
    private String message_id;
    private String express_id;
    private String shop_id;
    private String sn;
    private String user_id;
    private Integer num;
    private Integer points;
    private BigDecimal total_price;
    private BigDecimal actual_price;
    private BigDecimal rebate_price;
    private BigDecimal freight;
    private String address_id;
    private String contact;
    private String mobile;
    private String address;
    private String postal_code;
    private String ip;
    private String waybill_number;
    private String remark;
    private String seller_remark;
    private String cancel_remark;
    private Date pay_time;
    private Date delivery_time;
    private Date finish_time;
    private String trade_code;
    private String use_reason;
    private Integer use_type;
    private Integer trade_mode;
    private Integer type;
    private Integer is_real;
    private Integer status;
    private Integer sum_tag;
    private Date create_time;
    private Date modify_time;

    public String getOrder_id() {
        return order_id;
    }
    public void setOrder_id(String order_id) {
        this.order_id = order_id == null ? null : order_id.trim();
    }
    public String getMessage_id() {
        return message_id;
    }
    public void setMessage_id(String message_id) {
        this.message_id = message_id == null ? null : message_id.trim();
    }
    public String getExpress_id() {
        return express_id;
    }
    public void setExpress_id(String express_id) {
        this.express_id = express_id == null ? null : express_id.trim();
    }
    public String getShop_id() {
        return shop_id;
    }
    public void setShop_id(String shop_id) {
        this.shop_id = shop_id == null ? null : shop_id.trim();
    }
    public String getSn() {
        return sn;
    }
    public void setSn(String sn) {
        this.sn = sn == null ? null : sn.trim();
    }
    public String getUser_id() {
        return user_id;
    }
    public void setUser_id(String user_id) {
        this.user_id = user_id == null ? null : user_id.trim();
    }
    public Integer getNum() {
        return num;
    }
    public void setNum(Integer num) {
        this.num = num;
    }
    public Integer getPoints() {
        return points;
    }
    public void setPoints(Integer points) {
        this.points = points;
    }
    public BigDecimal getTotal_price() {
        return total_price;
    }
    public void setTotal_price(BigDecimal total_price) {
        this.total_price = total_price;
    }
    public BigDecimal getActual_price() {
        return actual_price;
    }
    public void setActual_price(BigDecimal actual_price) {
        this.actual_price = actual_price;
    }
    public BigDecimal getRebate_price() {
        return rebate_price;
    }
    public void setRebate_price(BigDecimal rebate_price) {
        this.rebate_price = rebate_price;
    }
    public BigDecimal getFreight() {
        return freight;
    }
    public void setFreight(BigDecimal freight) {
        this.freight = freight;
    }
    public String getAddress_id() {
        return address_id;
    }
    public void setAddress_id(String address_id) {
        this.address_id = address_id == null ? null : address_id.trim();
    }
    public String getContact() {
        return contact;
    }
    public void setContact(String contact) {
        this.contact = contact == null ? null : contact.trim();
    }
    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }
    public String getPostal_code() {
        return postal_code;
    }
    public void setPostal_code(String postal_code) {
        this.postal_code = postal_code == null ? null : postal_code.trim();
    }
    public String getIp() {
        return ip;
    }
    public void setIp(String ip) {
        this.ip = ip == null ? null : ip.trim();
    }
    public String getWaybill_number() {
        return waybill_number;
    }
    public void setWaybill_number(String waybill_number) {
        this.waybill_number = waybill_number == null ? null : waybill_number.trim();
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }
    public String getSeller_remark() {
        return seller_remark;
    }
    public void setSeller_remark(String seller_remark) {
        this.seller_remark = seller_remark == null ? null : seller_remark.trim();
    }
    public String getCancel_remark() {
        return cancel_remark;
    }
    public void setCancel_remark(String cancel_remark) {
        this.cancel_remark = cancel_remark == null ? null : cancel_remark.trim();
    }
    public Date getPay_time() {
        return pay_time;
    }
    public void setPay_time(Date pay_time) {
        this.pay_time = pay_time;
    }
    public Date getDelivery_time() {
        return delivery_time;
    }
    public void setDelivery_time(Date delivery_time) {
        this.delivery_time = delivery_time;
    }
    public Date getFinish_time() {
        return finish_time;
    }
    public void setFinish_time(Date finish_time) {
        this.finish_time = finish_time;
    }
    public String getTrade_code() {
        return trade_code;
    }
    public void setTrade_code(String trade_code) {
        this.trade_code = trade_code == null ? null : trade_code.trim();
    }
    public String getUse_reason() {
        return use_reason;
    }
    public void setUse_reason(String use_reason) {
        this.use_reason = use_reason == null ? null : use_reason.trim();
    }
    public Integer getUse_type() {
        return use_type;
    }
    public void setUse_type(Integer use_type) {
        this.use_type = use_type;
    }
    public Integer getTrade_mode() {
        return trade_mode;
    }
    public void setTrade_mode(Integer trade_mode) {
        this.trade_mode = trade_mode;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Integer getIs_real() {
        return is_real;
    }
    public void setIs_real(Integer is_real) {
        this.is_real = is_real;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getSum_tag() {
        return sum_tag;
    }
    public void setSum_tag(Integer sum_tag) {
        this.sum_tag = sum_tag;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}