package com.yqh.shop.model;

import java.math.BigDecimal;
import java.util.Date;

public class StatisticsUserOrder {

    private String user_order_id;
    private String user_id;
    private String message_id;
    private Integer order_num;
    private BigDecimal money;
    private Date the_date;
    private Date create_time;
    private Date modify_time;

    public String getUser_order_id() {
        return user_order_id;
    }
    public void setUser_order_id(String user_order_id) {
        this.user_order_id = user_order_id == null ? null : user_order_id.trim();
    }
    public String getUser_id() {
        return user_id;
    }
    public void setUser_id(String user_id) {
        this.user_id = user_id == null ? null : user_id.trim();
    }
    public String getMessage_id() {
        return message_id;
    }
    public void setMessage_id(String message_id) {
        this.message_id = message_id == null ? null : message_id.trim();
    }
    public Integer getOrder_num() {
        return order_num;
    }
    public void setOrder_num(Integer order_num) {
        this.order_num = order_num;
    }
    public BigDecimal getMoney() {
        return money;
    }
    public void setMoney(BigDecimal money) {
        this.money = money;
    }
    public Date getThe_date() {
        return the_date;
    }
    public void setThe_date(Date the_date) {
        this.the_date = the_date;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}