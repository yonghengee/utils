package com.yqh.shop.model;

import java.util.Date;

public class UserShopPic {

    private String shop_pic_id;
    private String shop_id;
    private String file_id;
    private String path;
    private Integer type;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getShop_pic_id() {
        return shop_pic_id;
    }
    public void setShop_pic_id(String shop_pic_id) {
        this.shop_pic_id = shop_pic_id == null ? null : shop_pic_id.trim();
    }
    public String getShop_id() {
        return shop_id;
    }
    public void setShop_id(String shop_id) {
        this.shop_id = shop_id == null ? null : shop_id.trim();
    }
    public String getFile_id() {
        return file_id;
    }
    public void setFile_id(String file_id) {
        this.file_id = file_id == null ? null : file_id.trim();
    }
    public String getPath() {
        return path;
    }
    public void setPath(String path) {
        this.path = path == null ? null : path.trim();
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}