package com.yqh.shop.model;

import java.util.Date;

public class OperatePolicyApplyDetails {

    private String policy_apply_details_id;
    private String policy_goods_id;
    private String policy_apply_id;
    private Integer task_num;
    private Integer finish_num;
    private Integer activity_status;
    private Date create_time;
    private Date modify_time;

    public String getPolicy_apply_details_id() {
        return policy_apply_details_id;
    }
    public void setPolicy_apply_details_id(String policy_apply_details_id) {
        this.policy_apply_details_id = policy_apply_details_id == null ? null : policy_apply_details_id.trim();
    }
    public String getPolicy_goods_id() {
        return policy_goods_id;
    }
    public void setPolicy_goods_id(String policy_goods_id) {
        this.policy_goods_id = policy_goods_id == null ? null : policy_goods_id.trim();
    }
    public String getPolicy_apply_id() {
        return policy_apply_id;
    }
    public void setPolicy_apply_id(String policy_apply_id) {
        this.policy_apply_id = policy_apply_id == null ? null : policy_apply_id.trim();
    }
    public Integer getTask_num() {
        return task_num;
    }
    public void setTask_num(Integer task_num) {
        this.task_num = task_num;
    }
    public Integer getFinish_num() {
        return finish_num;
    }
    public void setFinish_num(Integer finish_num) {
        this.finish_num = finish_num;
    }
    public Integer getActivity_status() {
        return activity_status;
    }
    public void setActivity_status(Integer activity_status) {
        this.activity_status = activity_status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}