package com.yqh.shop.model;

import java.util.Date;

public class UserShopLink {

    private String shop_link_id;
    private String role_id;
    private String user_id;
    private String shop_id;
    private Date create_time;
    private Date modify_time;

    public String getShop_link_id() {
        return shop_link_id;
    }
    public void setShop_link_id(String shop_link_id) {
        this.shop_link_id = shop_link_id == null ? null : shop_link_id.trim();
    }
    public String getRole_id() {
        return role_id;
    }
    public void setRole_id(String role_id) {
        this.role_id = role_id == null ? null : role_id.trim();
    }
    public String getUser_id() {
        return user_id;
    }
    public void setUser_id(String user_id) {
        this.user_id = user_id == null ? null : user_id.trim();
    }
    public String getShop_id() {
        return shop_id;
    }
    public void setShop_id(String shop_id) {
        this.shop_id = shop_id == null ? null : shop_id.trim();
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}