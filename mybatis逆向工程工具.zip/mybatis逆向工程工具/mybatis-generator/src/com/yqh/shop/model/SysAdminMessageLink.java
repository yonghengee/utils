package com.yqh.shop.model;

import java.util.Date;

public class SysAdminMessageLink {

    private String admin_message_link_id;
    private String admin_id;
    private String message_id;
    private String role_id;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getAdmin_message_link_id() {
        return admin_message_link_id;
    }
    public void setAdmin_message_link_id(String admin_message_link_id) {
        this.admin_message_link_id = admin_message_link_id == null ? null : admin_message_link_id.trim();
    }
    public String getAdmin_id() {
        return admin_id;
    }
    public void setAdmin_id(String admin_id) {
        this.admin_id = admin_id == null ? null : admin_id.trim();
    }
    public String getMessage_id() {
        return message_id;
    }
    public void setMessage_id(String message_id) {
        this.message_id = message_id == null ? null : message_id.trim();
    }
    public String getRole_id() {
        return role_id;
    }
    public void setRole_id(String role_id) {
        this.role_id = role_id == null ? null : role_id.trim();
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}