package com.yqh.shop.model;

import java.util.Date;

public class OperateQuestions {

    private String questions_id;
    private String message_id;
    private Integer message_type;
    private String title;
    private Integer status;
    private Integer answer_count;
    private Integer received_points;
    private Integer points;
    private Integer enables;
    private Date create_time;
    private Date modify_time;
    private String remark;

    public String getQuestions_id() {
        return questions_id;
    }
    public void setQuestions_id(String questions_id) {
        this.questions_id = questions_id == null ? null : questions_id.trim();
    }
    public String getMessage_id() {
        return message_id;
    }
    public void setMessage_id(String message_id) {
        this.message_id = message_id == null ? null : message_id.trim();
    }
    public Integer getMessage_type() {
        return message_type;
    }
    public void setMessage_type(Integer message_type) {
        this.message_type = message_type;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getAnswer_count() {
        return answer_count;
    }
    public void setAnswer_count(Integer answer_count) {
        this.answer_count = answer_count;
    }
    public Integer getReceived_points() {
        return received_points;
    }
    public void setReceived_points(Integer received_points) {
        this.received_points = received_points;
    }
    public Integer getPoints() {
        return points;
    }
    public void setPoints(Integer points) {
        this.points = points;
    }
    public Integer getEnables() {
        return enables;
    }
    public void setEnables(Integer enables) {
        this.enables = enables;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }
}