package com.yqh.shop.model;

import java.util.Date;

public class SysChat {

    private String chat_id;
    private String from_id;
    private String from_account;
    private Integer from_type;
    private String from_name;
    private String to_id;
    private String to_account;
    private Integer to_type;
    private String to_name;
    private String msg;
    private Integer from_un_read;
    private Integer to_un_read;
    private Date create_time;
    private Date modify_time;

    public String getChat_id() {
        return chat_id;
    }
    public void setChat_id(String chat_id) {
        this.chat_id = chat_id == null ? null : chat_id.trim();
    }
    public String getFrom_id() {
        return from_id;
    }
    public void setFrom_id(String from_id) {
        this.from_id = from_id == null ? null : from_id.trim();
    }
    public String getFrom_account() {
        return from_account;
    }
    public void setFrom_account(String from_account) {
        this.from_account = from_account == null ? null : from_account.trim();
    }
    public Integer getFrom_type() {
        return from_type;
    }
    public void setFrom_type(Integer from_type) {
        this.from_type = from_type;
    }
    public String getFrom_name() {
        return from_name;
    }
    public void setFrom_name(String from_name) {
        this.from_name = from_name == null ? null : from_name.trim();
    }
    public String getTo_id() {
        return to_id;
    }
    public void setTo_id(String to_id) {
        this.to_id = to_id == null ? null : to_id.trim();
    }
    public String getTo_account() {
        return to_account;
    }
    public void setTo_account(String to_account) {
        this.to_account = to_account == null ? null : to_account.trim();
    }
    public Integer getTo_type() {
        return to_type;
    }
    public void setTo_type(Integer to_type) {
        this.to_type = to_type;
    }
    public String getTo_name() {
        return to_name;
    }
    public void setTo_name(String to_name) {
        this.to_name = to_name == null ? null : to_name.trim();
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg == null ? null : msg.trim();
    }
    public Integer getFrom_un_read() {
        return from_un_read;
    }
    public void setFrom_un_read(Integer from_un_read) {
        this.from_un_read = from_un_read;
    }
    public Integer getTo_un_read() {
        return to_un_read;
    }
    public void setTo_un_read(Integer to_un_read) {
        this.to_un_read = to_un_read;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}