package com.yqh.shop.model;

import java.util.Date;

public class OperateChargeOrder {

    private String charge_order_id;
    private String sn;
    private String trade_code;
    private Integer trade_mode;
    private String admin_id;
    private String message_id;
    private Integer admin_type;
    private String ip;
    private Double money;
    private Integer status;
    private Date pay_time;
    private Integer sum_tag;
    private Date create_time;
    private Date modify_time;
    private String remark;

    public String getCharge_order_id() {
        return charge_order_id;
    }
    public void setCharge_order_id(String charge_order_id) {
        this.charge_order_id = charge_order_id == null ? null : charge_order_id.trim();
    }
    public String getSn() {
        return sn;
    }
    public void setSn(String sn) {
        this.sn = sn == null ? null : sn.trim();
    }
    public String getTrade_code() {
        return trade_code;
    }
    public void setTrade_code(String trade_code) {
        this.trade_code = trade_code == null ? null : trade_code.trim();
    }
    public Integer getTrade_mode() {
        return trade_mode;
    }
    public void setTrade_mode(Integer trade_mode) {
        this.trade_mode = trade_mode;
    }
    public String getAdmin_id() {
        return admin_id;
    }
    public void setAdmin_id(String admin_id) {
        this.admin_id = admin_id == null ? null : admin_id.trim();
    }
    public String getMessage_id() {
        return message_id;
    }
    public void setMessage_id(String message_id) {
        this.message_id = message_id == null ? null : message_id.trim();
    }
    public Integer getAdmin_type() {
        return admin_type;
    }
    public void setAdmin_type(Integer admin_type) {
        this.admin_type = admin_type;
    }
    public String getIp() {
        return ip;
    }
    public void setIp(String ip) {
        this.ip = ip == null ? null : ip.trim();
    }
    public Double getMoney() {
        return money;
    }
    public void setMoney(Double money) {
        this.money = money;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getPay_time() {
        return pay_time;
    }
    public void setPay_time(Date pay_time) {
        this.pay_time = pay_time;
    }
    public Integer getSum_tag() {
        return sum_tag;
    }
    public void setSum_tag(Integer sum_tag) {
        this.sum_tag = sum_tag;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }
}