package com.yqh.shop.model;

import java.util.Date;

public class OperateGraphicUser {

    private String graphic_user_id;
    private String graphic_id;
    private String user_id;
    private Integer points;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getGraphic_user_id() {
        return graphic_user_id;
    }
    public void setGraphic_user_id(String graphic_user_id) {
        this.graphic_user_id = graphic_user_id == null ? null : graphic_user_id.trim();
    }
    public String getGraphic_id() {
        return graphic_id;
    }
    public void setGraphic_id(String graphic_id) {
        this.graphic_id = graphic_id == null ? null : graphic_id.trim();
    }
    public String getUser_id() {
        return user_id;
    }
    public void setUser_id(String user_id) {
        this.user_id = user_id == null ? null : user_id.trim();
    }
    public Integer getPoints() {
        return points;
    }
    public void setPoints(Integer points) {
        this.points = points;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}