package com.yqh.shop.model;

import java.util.Date;

public class OperateGraphicTop {

    private String graphic_top_id;
    private String graphic_id;
    private Integer sort;
    private Integer top_enables;
    private Date top_start_time;
    private Date top_end_time;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getGraphic_top_id() {
        return graphic_top_id;
    }
    public void setGraphic_top_id(String graphic_top_id) {
        this.graphic_top_id = graphic_top_id == null ? null : graphic_top_id.trim();
    }
    public String getGraphic_id() {
        return graphic_id;
    }
    public void setGraphic_id(String graphic_id) {
        this.graphic_id = graphic_id == null ? null : graphic_id.trim();
    }
    public Integer getSort() {
        return sort;
    }
    public void setSort(Integer sort) {
        this.sort = sort;
    }
    public Integer getTop_enables() {
        return top_enables;
    }
    public void setTop_enables(Integer top_enables) {
        this.top_enables = top_enables;
    }
    public Date getTop_start_time() {
        return top_start_time;
    }
    public void setTop_start_time(Date top_start_time) {
        this.top_start_time = top_start_time;
    }
    public Date getTop_end_time() {
        return top_end_time;
    }
    public void setTop_end_time(Date top_end_time) {
        this.top_end_time = top_end_time;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}