package com.yqh.shop.model;

import java.util.Date;

public class UserMessageLink {

    private String message_link_id;
    private String message_id;
    private String shop_id;
    private String user_id;
    private Date create_time;
    private Date modify_time;

    public String getMessage_link_id() {
        return message_link_id;
    }
    public void setMessage_link_id(String message_link_id) {
        this.message_link_id = message_link_id == null ? null : message_link_id.trim();
    }
    public String getMessage_id() {
        return message_id;
    }
    public void setMessage_id(String message_id) {
        this.message_id = message_id == null ? null : message_id.trim();
    }
    public String getShop_id() {
        return shop_id;
    }
    public void setShop_id(String shop_id) {
        this.shop_id = shop_id == null ? null : shop_id.trim();
    }
    public String getUser_id() {
        return user_id;
    }
    public void setUser_id(String user_id) {
        this.user_id = user_id == null ? null : user_id.trim();
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}