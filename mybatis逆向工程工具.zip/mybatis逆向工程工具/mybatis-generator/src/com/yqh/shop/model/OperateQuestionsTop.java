package com.yqh.shop.model;

import java.util.Date;

public class OperateQuestionsTop {

    private String questions_top_id;
    private String questions_id;
    private Integer status;
    private Integer sort;
    private Integer top_enables;
    private Date top_start_time;
    private Date top_end_time;

    public String getQuestions_top_id() {
        return questions_top_id;
    }
    public void setQuestions_top_id(String questions_top_id) {
        this.questions_top_id = questions_top_id == null ? null : questions_top_id.trim();
    }
    public String getQuestions_id() {
        return questions_id;
    }
    public void setQuestions_id(String questions_id) {
        this.questions_id = questions_id == null ? null : questions_id.trim();
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getSort() {
        return sort;
    }
    public void setSort(Integer sort) {
        this.sort = sort;
    }
    public Integer getTop_enables() {
        return top_enables;
    }
    public void setTop_enables(Integer top_enables) {
        this.top_enables = top_enables;
    }
    public Date getTop_start_time() {
        return top_start_time;
    }
    public void setTop_start_time(Date top_start_time) {
        this.top_start_time = top_start_time;
    }
    public Date getTop_end_time() {
        return top_end_time;
    }
    public void setTop_end_time(Date top_end_time) {
        this.top_end_time = top_end_time;
    }
}