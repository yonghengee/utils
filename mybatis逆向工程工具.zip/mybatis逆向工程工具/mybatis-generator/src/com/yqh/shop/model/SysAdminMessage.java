package com.yqh.shop.model;

import java.util.Date;

public class SysAdminMessage {

    private String message_id;
    private String sn;
    private String photo_url;
    private String message_name;
    private String name;
    private String mobile;
    private String phone;
    private String province_id;
    private String province_name;
    private String city_id;
    private String city_name;
    private String area_id;
    private String area_name;
    private String address;
    private String introduction;
    private Integer sort;
    private Integer genre;
    private Integer type;
    private Integer status;
    private Integer enables;
    private Date create_time;
    private Date modify_time;
    private Date top_start_time;
    private Date top_end_time;
    private Integer top_enables;
    private String business_scope;
    private String distribution_mode;
    private String custom_features;
    private Date establish_time;

    public String getMessage_id() {
        return message_id;
    }
    public void setMessage_id(String message_id) {
        this.message_id = message_id == null ? null : message_id.trim();
    }
    public String getSn() {
        return sn;
    }
    public void setSn(String sn) {
        this.sn = sn == null ? null : sn.trim();
    }
    public String getPhoto_url() {
        return photo_url;
    }
    public void setPhoto_url(String photo_url) {
        this.photo_url = photo_url == null ? null : photo_url.trim();
    }
    public String getMessage_name() {
        return message_name;
    }
    public void setMessage_name(String message_name) {
        this.message_name = message_name == null ? null : message_name.trim();
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }
    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }
    public String getProvince_id() {
        return province_id;
    }
    public void setProvince_id(String province_id) {
        this.province_id = province_id == null ? null : province_id.trim();
    }
    public String getProvince_name() {
        return province_name;
    }
    public void setProvince_name(String province_name) {
        this.province_name = province_name == null ? null : province_name.trim();
    }
    public String getCity_id() {
        return city_id;
    }
    public void setCity_id(String city_id) {
        this.city_id = city_id == null ? null : city_id.trim();
    }
    public String getCity_name() {
        return city_name;
    }
    public void setCity_name(String city_name) {
        this.city_name = city_name == null ? null : city_name.trim();
    }
    public String getArea_id() {
        return area_id;
    }
    public void setArea_id(String area_id) {
        this.area_id = area_id == null ? null : area_id.trim();
    }
    public String getArea_name() {
        return area_name;
    }
    public void setArea_name(String area_name) {
        this.area_name = area_name == null ? null : area_name.trim();
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }
    public String getIntroduction() {
        return introduction;
    }
    public void setIntroduction(String introduction) {
        this.introduction = introduction == null ? null : introduction.trim();
    }
    public Integer getSort() {
        return sort;
    }
    public void setSort(Integer sort) {
        this.sort = sort;
    }
    public Integer getGenre() {
        return genre;
    }
    public void setGenre(Integer genre) {
        this.genre = genre;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getEnables() {
        return enables;
    }
    public void setEnables(Integer enables) {
        this.enables = enables;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
    public Date getTop_start_time() {
        return top_start_time;
    }
    public void setTop_start_time(Date top_start_time) {
        this.top_start_time = top_start_time;
    }
    public Date getTop_end_time() {
        return top_end_time;
    }
    public void setTop_end_time(Date top_end_time) {
        this.top_end_time = top_end_time;
    }
    public Integer getTop_enables() {
        return top_enables;
    }
    public void setTop_enables(Integer top_enables) {
        this.top_enables = top_enables;
    }
    public String getBusiness_scope() {
        return business_scope;
    }
    public void setBusiness_scope(String business_scope) {
        this.business_scope = business_scope == null ? null : business_scope.trim();
    }
    public String getDistribution_mode() {
        return distribution_mode;
    }
    public void setDistribution_mode(String distribution_mode) {
        this.distribution_mode = distribution_mode == null ? null : distribution_mode.trim();
    }
    public String getCustom_features() {
        return custom_features;
    }
    public void setCustom_features(String custom_features) {
        this.custom_features = custom_features == null ? null : custom_features.trim();
    }
    public Date getEstablish_time() {
        return establish_time;
    }
    public void setEstablish_time(Date establish_time) {
        this.establish_time = establish_time;
    }
}