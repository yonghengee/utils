package com.yqh.shop.model;

import java.math.BigDecimal;
import java.util.Date;

public class MallGoodsSku {

    private String goods_sku_id;
    private String goods_id;
    private String file_id;
    private String path;
    private String outer_code;
    private String product_code;
    private String properties;
    private String properties_name;
    private BigDecimal original_price;
    private BigDecimal sale_price;
    private Integer inventory;
    private Integer sales_volume;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getGoods_sku_id() {
        return goods_sku_id;
    }
    public void setGoods_sku_id(String goods_sku_id) {
        this.goods_sku_id = goods_sku_id == null ? null : goods_sku_id.trim();
    }
    public String getGoods_id() {
        return goods_id;
    }
    public void setGoods_id(String goods_id) {
        this.goods_id = goods_id == null ? null : goods_id.trim();
    }
    public String getFile_id() {
        return file_id;
    }
    public void setFile_id(String file_id) {
        this.file_id = file_id == null ? null : file_id.trim();
    }
    public String getPath() {
        return path;
    }
    public void setPath(String path) {
        this.path = path == null ? null : path.trim();
    }
    public String getOuter_code() {
        return outer_code;
    }
    public void setOuter_code(String outer_code) {
        this.outer_code = outer_code == null ? null : outer_code.trim();
    }
    public String getProduct_code() {
        return product_code;
    }
    public void setProduct_code(String product_code) {
        this.product_code = product_code == null ? null : product_code.trim();
    }
    public String getProperties() {
        return properties;
    }
    public void setProperties(String properties) {
        this.properties = properties == null ? null : properties.trim();
    }
    public String getProperties_name() {
        return properties_name;
    }
    public void setProperties_name(String properties_name) {
        this.properties_name = properties_name == null ? null : properties_name.trim();
    }
    public BigDecimal getOriginal_price() {
        return original_price;
    }
    public void setOriginal_price(BigDecimal original_price) {
        this.original_price = original_price;
    }
    public BigDecimal getSale_price() {
        return sale_price;
    }
    public void setSale_price(BigDecimal sale_price) {
        this.sale_price = sale_price;
    }
    public Integer getInventory() {
        return inventory;
    }
    public void setInventory(Integer inventory) {
        this.inventory = inventory;
    }
    public Integer getSales_volume() {
        return sales_volume;
    }
    public void setSales_volume(Integer sales_volume) {
        this.sales_volume = sales_volume;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}