package com.yqh.shop.model;

import java.util.Date;

public class OperateQuestionsSubject {

    private String questions_subject_id;
    private String questions_id;
    private String title;
    private Integer type;
    private Integer status;
    private Integer points;
    private Date create_time;
    private Date modify_time;
    private String remark;
    private Integer sort;

    public String getQuestions_subject_id() {
        return questions_subject_id;
    }
    public void setQuestions_subject_id(String questions_subject_id) {
        this.questions_subject_id = questions_subject_id == null ? null : questions_subject_id.trim();
    }
    public String getQuestions_id() {
        return questions_id;
    }
    public void setQuestions_id(String questions_id) {
        this.questions_id = questions_id == null ? null : questions_id.trim();
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getPoints() {
        return points;
    }
    public void setPoints(Integer points) {
        this.points = points;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }
    public Integer getSort() {
        return sort;
    }
    public void setSort(Integer sort) {
        this.sort = sort;
    }
}