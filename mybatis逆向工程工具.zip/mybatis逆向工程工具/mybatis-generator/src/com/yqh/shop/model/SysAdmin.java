package com.yqh.shop.model;

import java.util.Date;

public class SysAdmin {

    private String admin_id;
    private String sn;
    private String name;
    private String photo_url;
    private String mobile;
    private String password;
    private Integer type;
    private Integer status;
    private Integer enables;
    private String remark;
    private String chat_account;
    private Date create_time;
    private Date modify_time;

    public String getAdmin_id() {
        return admin_id;
    }
    public void setAdmin_id(String admin_id) {
        this.admin_id = admin_id == null ? null : admin_id.trim();
    }
    public String getSn() {
        return sn;
    }
    public void setSn(String sn) {
        this.sn = sn == null ? null : sn.trim();
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }
    public String getPhoto_url() {
        return photo_url;
    }
    public void setPhoto_url(String photo_url) {
        this.photo_url = photo_url == null ? null : photo_url.trim();
    }
    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getEnables() {
        return enables;
    }
    public void setEnables(Integer enables) {
        this.enables = enables;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }
    public String getChat_account() {
        return chat_account;
    }
    public void setChat_account(String chat_account) {
        this.chat_account = chat_account == null ? null : chat_account.trim();
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}