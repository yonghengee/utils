package com.yqh.shop.model;

import java.util.Date;

public class SysAdminMessagePic {

    private String message_pic_id;
    private String message_id;
    private String file_id;
    private String path;
    private Integer type;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getMessage_pic_id() {
        return message_pic_id;
    }
    public void setMessage_pic_id(String message_pic_id) {
        this.message_pic_id = message_pic_id == null ? null : message_pic_id.trim();
    }
    public String getMessage_id() {
        return message_id;
    }
    public void setMessage_id(String message_id) {
        this.message_id = message_id == null ? null : message_id.trim();
    }
    public String getFile_id() {
        return file_id;
    }
    public void setFile_id(String file_id) {
        this.file_id = file_id == null ? null : file_id.trim();
    }
    public String getPath() {
        return path;
    }
    public void setPath(String path) {
        this.path = path == null ? null : path.trim();
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}