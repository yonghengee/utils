package com.yqh.shop.model;

import java.math.BigDecimal;
import java.util.Date;

public class UserShop {

    private String shop_id;
    private String p_shop_id;
    private String name;
    private Integer type;
    private String contacts;
    private String mobile;
    private String province_id;
    private String province_name;
    private String city_id;
    private String city_name;
    private String area_id;
    private String area_name;
    private String address;
    private Integer status;
    private Integer enables;
    private Integer link_type;
    private Integer apply_status;
    private String remark;
    private Integer accounts_status;
    private BigDecimal discount;
    private Integer is_discount;
    private BigDecimal total_order;
    private String random_code;
    private Date create_time;
    private Date modify_time;

    public String getShop_id() {
        return shop_id;
    }
    public void setShop_id(String shop_id) {
        this.shop_id = shop_id == null ? null : shop_id.trim();
    }
    public String getP_shop_id() {
        return p_shop_id;
    }
    public void setP_shop_id(String p_shop_id) {
        this.p_shop_id = p_shop_id == null ? null : p_shop_id.trim();
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public String getContacts() {
        return contacts;
    }
    public void setContacts(String contacts) {
        this.contacts = contacts == null ? null : contacts.trim();
    }
    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }
    public String getProvince_id() {
        return province_id;
    }
    public void setProvince_id(String province_id) {
        this.province_id = province_id == null ? null : province_id.trim();
    }
    public String getProvince_name() {
        return province_name;
    }
    public void setProvince_name(String province_name) {
        this.province_name = province_name == null ? null : province_name.trim();
    }
    public String getCity_id() {
        return city_id;
    }
    public void setCity_id(String city_id) {
        this.city_id = city_id == null ? null : city_id.trim();
    }
    public String getCity_name() {
        return city_name;
    }
    public void setCity_name(String city_name) {
        this.city_name = city_name == null ? null : city_name.trim();
    }
    public String getArea_id() {
        return area_id;
    }
    public void setArea_id(String area_id) {
        this.area_id = area_id == null ? null : area_id.trim();
    }
    public String getArea_name() {
        return area_name;
    }
    public void setArea_name(String area_name) {
        this.area_name = area_name == null ? null : area_name.trim();
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getEnables() {
        return enables;
    }
    public void setEnables(Integer enables) {
        this.enables = enables;
    }
    public Integer getLink_type() {
        return link_type;
    }
    public void setLink_type(Integer link_type) {
        this.link_type = link_type;
    }
    public Integer getApply_status() {
        return apply_status;
    }
    public void setApply_status(Integer apply_status) {
        this.apply_status = apply_status;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }
    public Integer getAccounts_status() {
        return accounts_status;
    }
    public void setAccounts_status(Integer accounts_status) {
        this.accounts_status = accounts_status;
    }
    public BigDecimal getDiscount() {
        return discount;
    }
    public void setDiscount(BigDecimal discount) {
        this.discount = discount;
    }
    public Integer getIs_discount() {
        return is_discount;
    }
    public void setIs_discount(Integer is_discount) {
        this.is_discount = is_discount;
    }
    public BigDecimal getTotal_order() {
        return total_order;
    }
    public void setTotal_order(BigDecimal total_order) {
        this.total_order = total_order;
    }
    public String getRandom_code() {
        return random_code;
    }
    public void setRandom_code(String random_code) {
        this.random_code = random_code == null ? null : random_code.trim();
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}