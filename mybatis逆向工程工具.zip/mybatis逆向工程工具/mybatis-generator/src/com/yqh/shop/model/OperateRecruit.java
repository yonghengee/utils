package com.yqh.shop.model;

import java.util.Date;

public class OperateRecruit {

    private String recruit_id;
    private String corporate_name;
    private String wages;
    private String job;
    private Integer num;
    private String mailbox;
    private String province_id;
    private String province_name;
    private String city_id;
    private String city_name;
    private String area_id;
    private String area_name;
    private String address;
    private String mobile;
    private String described;
    private String welfare;
    private String business_id;
    private Integer business_type;
    private Integer see_count;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getRecruit_id() {
        return recruit_id;
    }
    public void setRecruit_id(String recruit_id) {
        this.recruit_id = recruit_id == null ? null : recruit_id.trim();
    }
    public String getCorporate_name() {
        return corporate_name;
    }
    public void setCorporate_name(String corporate_name) {
        this.corporate_name = corporate_name == null ? null : corporate_name.trim();
    }
    public String getWages() {
        return wages;
    }
    public void setWages(String wages) {
        this.wages = wages == null ? null : wages.trim();
    }
    public String getJob() {
        return job;
    }
    public void setJob(String job) {
        this.job = job == null ? null : job.trim();
    }
    public Integer getNum() {
        return num;
    }
    public void setNum(Integer num) {
        this.num = num;
    }
    public String getMailbox() {
        return mailbox;
    }
    public void setMailbox(String mailbox) {
        this.mailbox = mailbox == null ? null : mailbox.trim();
    }
    public String getProvince_id() {
        return province_id;
    }
    public void setProvince_id(String province_id) {
        this.province_id = province_id == null ? null : province_id.trim();
    }
    public String getProvince_name() {
        return province_name;
    }
    public void setProvince_name(String province_name) {
        this.province_name = province_name == null ? null : province_name.trim();
    }
    public String getCity_id() {
        return city_id;
    }
    public void setCity_id(String city_id) {
        this.city_id = city_id == null ? null : city_id.trim();
    }
    public String getCity_name() {
        return city_name;
    }
    public void setCity_name(String city_name) {
        this.city_name = city_name == null ? null : city_name.trim();
    }
    public String getArea_id() {
        return area_id;
    }
    public void setArea_id(String area_id) {
        this.area_id = area_id == null ? null : area_id.trim();
    }
    public String getArea_name() {
        return area_name;
    }
    public void setArea_name(String area_name) {
        this.area_name = area_name == null ? null : area_name.trim();
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }
    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }
    public String getDescribed() {
        return described;
    }
    public void setDescribed(String described) {
        this.described = described == null ? null : described.trim();
    }
    public String getWelfare() {
        return welfare;
    }
    public void setWelfare(String welfare) {
        this.welfare = welfare == null ? null : welfare.trim();
    }
    public String getBusiness_id() {
        return business_id;
    }
    public void setBusiness_id(String business_id) {
        this.business_id = business_id == null ? null : business_id.trim();
    }
    public Integer getBusiness_type() {
        return business_type;
    }
    public void setBusiness_type(Integer business_type) {
        this.business_type = business_type;
    }
    public Integer getSee_count() {
        return see_count;
    }
    public void setSee_count(Integer see_count) {
        this.see_count = see_count;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}