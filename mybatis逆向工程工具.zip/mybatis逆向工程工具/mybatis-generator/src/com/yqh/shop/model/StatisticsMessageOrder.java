package com.yqh.shop.model;

import java.math.BigDecimal;
import java.util.Date;

public class StatisticsMessageOrder {

    private String message_order_id;
    private String message_id;
    private String business_id;
    private Integer order_num;
    private Integer goods_num;
    private BigDecimal money;
    private Integer type;
    private Date the_date;
    private Date create_time;
    private Date modify_time;

    public String getMessage_order_id() {
        return message_order_id;
    }
    public void setMessage_order_id(String message_order_id) {
        this.message_order_id = message_order_id == null ? null : message_order_id.trim();
    }
    public String getMessage_id() {
        return message_id;
    }
    public void setMessage_id(String message_id) {
        this.message_id = message_id == null ? null : message_id.trim();
    }
    public String getBusiness_id() {
        return business_id;
    }
    public void setBusiness_id(String business_id) {
        this.business_id = business_id == null ? null : business_id.trim();
    }
    public Integer getOrder_num() {
        return order_num;
    }
    public void setOrder_num(Integer order_num) {
        this.order_num = order_num;
    }
    public Integer getGoods_num() {
        return goods_num;
    }
    public void setGoods_num(Integer goods_num) {
        this.goods_num = goods_num;
    }
    public BigDecimal getMoney() {
        return money;
    }
    public void setMoney(BigDecimal money) {
        this.money = money;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Date getThe_date() {
        return the_date;
    }
    public void setThe_date(Date the_date) {
        this.the_date = the_date;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}