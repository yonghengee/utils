package com.yqh.shop.model;

import java.math.BigDecimal;
import java.util.Date;

public class MallOrderDetails {

    private String order_details_id;
    private String order_id;
    private String business_id;
    private String goods_sku_id;
    private String path;
    private String name;
    private Integer num;
    private BigDecimal original_price;
    private BigDecimal sale_price;
    private BigDecimal rebate_price;
    private BigDecimal total_price;
    private BigDecimal actual_price;
    private Integer type;
    private String quote_goods_id;
    private String quote_message_id;
    private Date create_time;
    private Date modify_time;

    public String getOrder_details_id() {
        return order_details_id;
    }
    public void setOrder_details_id(String order_details_id) {
        this.order_details_id = order_details_id == null ? null : order_details_id.trim();
    }
    public String getOrder_id() {
        return order_id;
    }
    public void setOrder_id(String order_id) {
        this.order_id = order_id == null ? null : order_id.trim();
    }
    public String getBusiness_id() {
        return business_id;
    }
    public void setBusiness_id(String business_id) {
        this.business_id = business_id == null ? null : business_id.trim();
    }
    public String getGoods_sku_id() {
        return goods_sku_id;
    }
    public void setGoods_sku_id(String goods_sku_id) {
        this.goods_sku_id = goods_sku_id == null ? null : goods_sku_id.trim();
    }
    public String getPath() {
        return path;
    }
    public void setPath(String path) {
        this.path = path == null ? null : path.trim();
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }
    public Integer getNum() {
        return num;
    }
    public void setNum(Integer num) {
        this.num = num;
    }
    public BigDecimal getOriginal_price() {
        return original_price;
    }
    public void setOriginal_price(BigDecimal original_price) {
        this.original_price = original_price;
    }
    public BigDecimal getSale_price() {
        return sale_price;
    }
    public void setSale_price(BigDecimal sale_price) {
        this.sale_price = sale_price;
    }
    public BigDecimal getRebate_price() {
        return rebate_price;
    }
    public void setRebate_price(BigDecimal rebate_price) {
        this.rebate_price = rebate_price;
    }
    public BigDecimal getTotal_price() {
        return total_price;
    }
    public void setTotal_price(BigDecimal total_price) {
        this.total_price = total_price;
    }
    public BigDecimal getActual_price() {
        return actual_price;
    }
    public void setActual_price(BigDecimal actual_price) {
        this.actual_price = actual_price;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public String getQuote_goods_id() {
        return quote_goods_id;
    }
    public void setQuote_goods_id(String quote_goods_id) {
        this.quote_goods_id = quote_goods_id == null ? null : quote_goods_id.trim();
    }
    public String getQuote_message_id() {
        return quote_message_id;
    }
    public void setQuote_message_id(String quote_message_id) {
        this.quote_message_id = quote_message_id == null ? null : quote_message_id.trim();
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}