package com.yqh.shop.model;

import java.math.BigDecimal;
import java.util.Date;

public class OperatePointsDetails {

    private String points_detail_id;
    private String points_id;
    private String message_id;
    private String user_id;
    private String business_id;
    private Integer income;
    private Integer payment;
    private Integer points;
    private Integer before_points;
    private String points_rule_code;
    private BigDecimal points_rate;
    private Integer type;
    private Integer message_type;
    private String described;
    private Date create_time;
    private Date modify_time;
    private String admin_id;

    public String getPoints_detail_id() {
        return points_detail_id;
    }
    public void setPoints_detail_id(String points_detail_id) {
        this.points_detail_id = points_detail_id == null ? null : points_detail_id.trim();
    }
    public String getPoints_id() {
        return points_id;
    }
    public void setPoints_id(String points_id) {
        this.points_id = points_id == null ? null : points_id.trim();
    }
    public String getMessage_id() {
        return message_id;
    }
    public void setMessage_id(String message_id) {
        this.message_id = message_id == null ? null : message_id.trim();
    }
    public String getUser_id() {
        return user_id;
    }
    public void setUser_id(String user_id) {
        this.user_id = user_id == null ? null : user_id.trim();
    }
    public String getBusiness_id() {
        return business_id;
    }
    public void setBusiness_id(String business_id) {
        this.business_id = business_id == null ? null : business_id.trim();
    }
    public Integer getIncome() {
        return income;
    }
    public void setIncome(Integer income) {
        this.income = income;
    }
    public Integer getPayment() {
        return payment;
    }
    public void setPayment(Integer payment) {
        this.payment = payment;
    }
    public Integer getPoints() {
        return points;
    }
    public void setPoints(Integer points) {
        this.points = points;
    }
    public Integer getBefore_points() {
        return before_points;
    }
    public void setBefore_points(Integer before_points) {
        this.before_points = before_points;
    }
    public String getPoints_rule_code() {
        return points_rule_code;
    }
    public void setPoints_rule_code(String points_rule_code) {
        this.points_rule_code = points_rule_code == null ? null : points_rule_code.trim();
    }
    public BigDecimal getPoints_rate() {
        return points_rate;
    }
    public void setPoints_rate(BigDecimal points_rate) {
        this.points_rate = points_rate;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Integer getMessage_type() {
        return message_type;
    }
    public void setMessage_type(Integer message_type) {
        this.message_type = message_type;
    }
    public String getDescribed() {
        return described;
    }
    public void setDescribed(String described) {
        this.described = described == null ? null : described.trim();
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
    public String getAdmin_id() {
        return admin_id;
    }
    public void setAdmin_id(String admin_id) {
        this.admin_id = admin_id == null ? null : admin_id.trim();
    }
}