package com.yqh.shop.model;

import java.util.Date;

public class MallOrderExamine {

    private String order_examine_id;
    private String order_id;
    private String user_id;
    private String shop_id;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getOrder_examine_id() {
        return order_examine_id;
    }
    public void setOrder_examine_id(String order_examine_id) {
        this.order_examine_id = order_examine_id == null ? null : order_examine_id.trim();
    }
    public String getOrder_id() {
        return order_id;
    }
    public void setOrder_id(String order_id) {
        this.order_id = order_id == null ? null : order_id.trim();
    }
    public String getUser_id() {
        return user_id;
    }
    public void setUser_id(String user_id) {
        this.user_id = user_id == null ? null : user_id.trim();
    }
    public String getShop_id() {
        return shop_id;
    }
    public void setShop_id(String shop_id) {
        this.shop_id = shop_id == null ? null : shop_id.trim();
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}