package com.yqh.shop.model;

import java.util.Date;

public class MallParamValue {

    private Integer value_id;
    private Integer param_id;
    private Integer goods_type_id;
    private String value;
    private Integer sort;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public Integer getValue_id() {
        return value_id;
    }
    public void setValue_id(Integer value_id) {
        this.value_id = value_id;
    }
    public Integer getParam_id() {
        return param_id;
    }
    public void setParam_id(Integer param_id) {
        this.param_id = param_id;
    }
    public Integer getGoods_type_id() {
        return goods_type_id;
    }
    public void setGoods_type_id(Integer goods_type_id) {
        this.goods_type_id = goods_type_id;
    }
    public String getValue() {
        return value;
    }
    public void setValue(String value) {
        this.value = value == null ? null : value.trim();
    }
    public Integer getSort() {
        return sort;
    }
    public void setSort(Integer sort) {
        this.sort = sort;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}