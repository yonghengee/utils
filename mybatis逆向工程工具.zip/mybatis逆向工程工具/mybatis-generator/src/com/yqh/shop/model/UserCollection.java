package com.yqh.shop.model;

import java.util.Date;

public class UserCollection {

    private String collection_id;
    private String user_id;
    private String business_id;
    private Integer type;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getCollection_id() {
        return collection_id;
    }
    public void setCollection_id(String collection_id) {
        this.collection_id = collection_id == null ? null : collection_id.trim();
    }
    public String getUser_id() {
        return user_id;
    }
    public void setUser_id(String user_id) {
        this.user_id = user_id == null ? null : user_id.trim();
    }
    public String getBusiness_id() {
        return business_id;
    }
    public void setBusiness_id(String business_id) {
        this.business_id = business_id == null ? null : business_id.trim();
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}