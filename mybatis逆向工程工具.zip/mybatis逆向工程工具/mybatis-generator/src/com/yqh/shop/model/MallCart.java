package com.yqh.shop.model;

import java.util.Date;

public class MallCart {

    private String cart_id;
    private String message_id;
    private String user_id;
    private String business_id;
    private String goods_sku_id;
    private Integer num;
    private Integer type;
    private Integer goods_type;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getCart_id() {
        return cart_id;
    }
    public void setCart_id(String cart_id) {
        this.cart_id = cart_id == null ? null : cart_id.trim();
    }
    public String getMessage_id() {
        return message_id;
    }
    public void setMessage_id(String message_id) {
        this.message_id = message_id == null ? null : message_id.trim();
    }
    public String getUser_id() {
        return user_id;
    }
    public void setUser_id(String user_id) {
        this.user_id = user_id == null ? null : user_id.trim();
    }
    public String getBusiness_id() {
        return business_id;
    }
    public void setBusiness_id(String business_id) {
        this.business_id = business_id == null ? null : business_id.trim();
    }
    public String getGoods_sku_id() {
        return goods_sku_id;
    }
    public void setGoods_sku_id(String goods_sku_id) {
        this.goods_sku_id = goods_sku_id == null ? null : goods_sku_id.trim();
    }
    public Integer getNum() {
        return num;
    }
    public void setNum(Integer num) {
        this.num = num;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Integer getGoods_type() {
        return goods_type;
    }
    public void setGoods_type(Integer goods_type) {
        this.goods_type = goods_type;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}