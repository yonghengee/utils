package com.yqh.shop.model;

import java.util.Date;

public class MallExpress {

    private String express_id;
    private String express_name;
    private String express_code;
    private Date create_time;

    public String getExpress_id() {
        return express_id;
    }
    public void setExpress_id(String express_id) {
        this.express_id = express_id == null ? null : express_id.trim();
    }
    public String getExpress_name() {
        return express_name;
    }
    public void setExpress_name(String express_name) {
        this.express_name = express_name == null ? null : express_name.trim();
    }
    public String getExpress_code() {
        return express_code;
    }
    public void setExpress_code(String express_code) {
        this.express_code = express_code == null ? null : express_code.trim();
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
}