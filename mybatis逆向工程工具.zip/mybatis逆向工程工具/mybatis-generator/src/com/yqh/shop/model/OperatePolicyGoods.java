package com.yqh.shop.model;

import java.util.Date;

public class OperatePolicyGoods {

    private String policy_goods_id;
    private String policy_id;
    private String goods_id;
    private String goods_sku_id;
    private Integer task_num;
    private Integer points;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getPolicy_goods_id() {
        return policy_goods_id;
    }
    public void setPolicy_goods_id(String policy_goods_id) {
        this.policy_goods_id = policy_goods_id == null ? null : policy_goods_id.trim();
    }
    public String getPolicy_id() {
        return policy_id;
    }
    public void setPolicy_id(String policy_id) {
        this.policy_id = policy_id == null ? null : policy_id.trim();
    }
    public String getGoods_id() {
        return goods_id;
    }
    public void setGoods_id(String goods_id) {
        this.goods_id = goods_id == null ? null : goods_id.trim();
    }
    public String getGoods_sku_id() {
        return goods_sku_id;
    }
    public void setGoods_sku_id(String goods_sku_id) {
        this.goods_sku_id = goods_sku_id == null ? null : goods_sku_id.trim();
    }
    public Integer getTask_num() {
        return task_num;
    }
    public void setTask_num(Integer task_num) {
        this.task_num = task_num;
    }
    public Integer getPoints() {
        return points;
    }
    public void setPoints(Integer points) {
        this.points = points;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}