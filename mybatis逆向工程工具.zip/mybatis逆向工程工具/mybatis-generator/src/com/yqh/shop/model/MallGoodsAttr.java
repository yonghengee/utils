package com.yqh.shop.model;

import java.util.Date;

public class MallGoodsAttr {

    private String goods_attr_id;
    private Integer param_id;
    private Integer value_id;
    private String goods_sku_id;
    private String goods_id;
    private Integer is_sku;
    private String param_name;
    private String value_name;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getGoods_attr_id() {
        return goods_attr_id;
    }
    public void setGoods_attr_id(String goods_attr_id) {
        this.goods_attr_id = goods_attr_id == null ? null : goods_attr_id.trim();
    }
    public Integer getParam_id() {
        return param_id;
    }
    public void setParam_id(Integer param_id) {
        this.param_id = param_id;
    }
    public Integer getValue_id() {
        return value_id;
    }
    public void setValue_id(Integer value_id) {
        this.value_id = value_id;
    }
    public String getGoods_sku_id() {
        return goods_sku_id;
    }
    public void setGoods_sku_id(String goods_sku_id) {
        this.goods_sku_id = goods_sku_id == null ? null : goods_sku_id.trim();
    }
    public String getGoods_id() {
        return goods_id;
    }
    public void setGoods_id(String goods_id) {
        this.goods_id = goods_id == null ? null : goods_id.trim();
    }
    public Integer getIs_sku() {
        return is_sku;
    }
    public void setIs_sku(Integer is_sku) {
        this.is_sku = is_sku;
    }
    public String getParam_name() {
        return param_name;
    }
    public void setParam_name(String param_name) {
        this.param_name = param_name == null ? null : param_name.trim();
    }
    public String getValue_name() {
        return value_name;
    }
    public void setValue_name(String value_name) {
        this.value_name = value_name == null ? null : value_name.trim();
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}