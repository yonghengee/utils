package com.yqh.shop.model;

import java.math.BigDecimal;
import java.util.Date;

public class MallGoodsActivityDetails {

    private String activity_details_id;
    private String activity_id;
    private String goods_id;
    private String message_id;
    private String goods_sku_id;
    private BigDecimal activity_price;
    private Integer sort;
    private Date start_time;
    private Date end_time;
    private Integer on_sale;
    private Integer status;
    private Integer type;
    private Integer goods_type;
    private Date create_time;
    private Date modify_time;

    public String getActivity_details_id() {
        return activity_details_id;
    }
    public void setActivity_details_id(String activity_details_id) {
        this.activity_details_id = activity_details_id == null ? null : activity_details_id.trim();
    }
    public String getActivity_id() {
        return activity_id;
    }
    public void setActivity_id(String activity_id) {
        this.activity_id = activity_id == null ? null : activity_id.trim();
    }
    public String getGoods_id() {
        return goods_id;
    }
    public void setGoods_id(String goods_id) {
        this.goods_id = goods_id == null ? null : goods_id.trim();
    }
    public String getMessage_id() {
        return message_id;
    }
    public void setMessage_id(String message_id) {
        this.message_id = message_id == null ? null : message_id.trim();
    }
    public String getGoods_sku_id() {
        return goods_sku_id;
    }
    public void setGoods_sku_id(String goods_sku_id) {
        this.goods_sku_id = goods_sku_id == null ? null : goods_sku_id.trim();
    }
    public BigDecimal getActivity_price() {
        return activity_price;
    }
    public void setActivity_price(BigDecimal activity_price) {
        this.activity_price = activity_price;
    }
    public Integer getSort() {
        return sort;
    }
    public void setSort(Integer sort) {
        this.sort = sort;
    }
    public Date getStart_time() {
        return start_time;
    }
    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }
    public Date getEnd_time() {
        return end_time;
    }
    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }
    public Integer getOn_sale() {
        return on_sale;
    }
    public void setOn_sale(Integer on_sale) {
        this.on_sale = on_sale;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Integer getGoods_type() {
        return goods_type;
    }
    public void setGoods_type(Integer goods_type) {
        this.goods_type = goods_type;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}