package com.yqh.shop.model;

import java.util.Date;

public class MallEvaluate {

    private String evaluate_id;
    private String order_id;
    private String business_id;
    private String user_id;
    private String name;
    private String photo_url;
    private String content;
    private Integer see_count;
    private Integer spot_laud;
    private Integer business_type;
    private Integer evaluate_type;
    private String p_evaluate_id;
    private Integer status;
    private Integer is_read;
    private Integer is_show;
    private Integer score;
    private Date create_time;
    private Date modify_time;

    public String getEvaluate_id() {
        return evaluate_id;
    }
    public void setEvaluate_id(String evaluate_id) {
        this.evaluate_id = evaluate_id == null ? null : evaluate_id.trim();
    }
    public String getOrder_id() {
        return order_id;
    }
    public void setOrder_id(String order_id) {
        this.order_id = order_id == null ? null : order_id.trim();
    }
    public String getBusiness_id() {
        return business_id;
    }
    public void setBusiness_id(String business_id) {
        this.business_id = business_id == null ? null : business_id.trim();
    }
    public String getUser_id() {
        return user_id;
    }
    public void setUser_id(String user_id) {
        this.user_id = user_id == null ? null : user_id.trim();
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }
    public String getPhoto_url() {
        return photo_url;
    }
    public void setPhoto_url(String photo_url) {
        this.photo_url = photo_url == null ? null : photo_url.trim();
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }
    public Integer getSee_count() {
        return see_count;
    }
    public void setSee_count(Integer see_count) {
        this.see_count = see_count;
    }
    public Integer getSpot_laud() {
        return spot_laud;
    }
    public void setSpot_laud(Integer spot_laud) {
        this.spot_laud = spot_laud;
    }
    public Integer getBusiness_type() {
        return business_type;
    }
    public void setBusiness_type(Integer business_type) {
        this.business_type = business_type;
    }
    public Integer getEvaluate_type() {
        return evaluate_type;
    }
    public void setEvaluate_type(Integer evaluate_type) {
        this.evaluate_type = evaluate_type;
    }
    public String getP_evaluate_id() {
        return p_evaluate_id;
    }
    public void setP_evaluate_id(String p_evaluate_id) {
        this.p_evaluate_id = p_evaluate_id == null ? null : p_evaluate_id.trim();
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getIs_read() {
        return is_read;
    }
    public void setIs_read(Integer is_read) {
        this.is_read = is_read;
    }
    public Integer getIs_show() {
        return is_show;
    }
    public void setIs_show(Integer is_show) {
        this.is_show = is_show;
    }
    public Integer getScore() {
        return score;
    }
    public void setScore(Integer score) {
        this.score = score;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}