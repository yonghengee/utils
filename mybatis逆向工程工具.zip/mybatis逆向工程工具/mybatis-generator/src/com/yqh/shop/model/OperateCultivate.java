package com.yqh.shop.model;

import java.util.Date;

public class OperateCultivate {

    private String cultivate_id;
    private String message_id;
    private Integer message_type;
    private String cultivate_subject_id;
    private String title;
    private String path;
    private String video_path;
    private Integer type;
    private Integer see_count;
    private Integer enables;
    private Integer status;
    private Date create_time;
    private Date modify_time;
    private String content;

    public String getCultivate_id() {
        return cultivate_id;
    }
    public void setCultivate_id(String cultivate_id) {
        this.cultivate_id = cultivate_id == null ? null : cultivate_id.trim();
    }
    public String getMessage_id() {
        return message_id;
    }
    public void setMessage_id(String message_id) {
        this.message_id = message_id == null ? null : message_id.trim();
    }
    public Integer getMessage_type() {
        return message_type;
    }
    public void setMessage_type(Integer message_type) {
        this.message_type = message_type;
    }
    public String getCultivate_subject_id() {
        return cultivate_subject_id;
    }
    public void setCultivate_subject_id(String cultivate_subject_id) {
        this.cultivate_subject_id = cultivate_subject_id == null ? null : cultivate_subject_id.trim();
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }
    public String getPath() {
        return path;
    }
    public void setPath(String path) {
        this.path = path == null ? null : path.trim();
    }
    public String getVideo_path() {
        return video_path;
    }
    public void setVideo_path(String video_path) {
        this.video_path = video_path == null ? null : video_path.trim();
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Integer getSee_count() {
        return see_count;
    }
    public void setSee_count(Integer see_count) {
        this.see_count = see_count;
    }
    public Integer getEnables() {
        return enables;
    }
    public void setEnables(Integer enables) {
        this.enables = enables;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }
}