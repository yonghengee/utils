package com.yqh.shop.model;

import java.util.Date;

public class UserAddress {

    private String address_id;
    private String user_id;
    private String contacts;
    private String mobile;
    private Integer is_default;
    private String postal_code;
    private String province_id;
    private String province_name;
    private String city_id;
    private String city_name;
    private String area_id;
    private String area_name;
    private String address;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getAddress_id() {
        return address_id;
    }
    public void setAddress_id(String address_id) {
        this.address_id = address_id == null ? null : address_id.trim();
    }
    public String getUser_id() {
        return user_id;
    }
    public void setUser_id(String user_id) {
        this.user_id = user_id == null ? null : user_id.trim();
    }
    public String getContacts() {
        return contacts;
    }
    public void setContacts(String contacts) {
        this.contacts = contacts == null ? null : contacts.trim();
    }
    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }
    public Integer getIs_default() {
        return is_default;
    }
    public void setIs_default(Integer is_default) {
        this.is_default = is_default;
    }
    public String getPostal_code() {
        return postal_code;
    }
    public void setPostal_code(String postal_code) {
        this.postal_code = postal_code == null ? null : postal_code.trim();
    }
    public String getProvince_id() {
        return province_id;
    }
    public void setProvince_id(String province_id) {
        this.province_id = province_id == null ? null : province_id.trim();
    }
    public String getProvince_name() {
        return province_name;
    }
    public void setProvince_name(String province_name) {
        this.province_name = province_name == null ? null : province_name.trim();
    }
    public String getCity_id() {
        return city_id;
    }
    public void setCity_id(String city_id) {
        this.city_id = city_id == null ? null : city_id.trim();
    }
    public String getCity_name() {
        return city_name;
    }
    public void setCity_name(String city_name) {
        this.city_name = city_name == null ? null : city_name.trim();
    }
    public String getArea_id() {
        return area_id;
    }
    public void setArea_id(String area_id) {
        this.area_id = area_id == null ? null : area_id.trim();
    }
    public String getArea_name() {
        return area_name;
    }
    public void setArea_name(String area_name) {
        this.area_name = area_name == null ? null : area_name.trim();
    }
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}