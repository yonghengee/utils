package com.yqh.shop.model;

public class OperateQuestionsAnswerDetails {

    private String questions_answer_details_id;
    private String answer_id;
    private String questions_option_id;
    private String questions_subject_id;

    public String getQuestions_answer_details_id() {
        return questions_answer_details_id;
    }
    public void setQuestions_answer_details_id(String questions_answer_details_id) {
        this.questions_answer_details_id = questions_answer_details_id == null ? null : questions_answer_details_id.trim();
    }
    public String getAnswer_id() {
        return answer_id;
    }
    public void setAnswer_id(String answer_id) {
        this.answer_id = answer_id == null ? null : answer_id.trim();
    }
    public String getQuestions_option_id() {
        return questions_option_id;
    }
    public void setQuestions_option_id(String questions_option_id) {
        this.questions_option_id = questions_option_id == null ? null : questions_option_id.trim();
    }
    public String getQuestions_subject_id() {
        return questions_subject_id;
    }
    public void setQuestions_subject_id(String questions_subject_id) {
        this.questions_subject_id = questions_subject_id == null ? null : questions_subject_id.trim();
    }
}