package com.yqh.shop.model;

import java.util.Date;

public class OperateQuestionsOption {

    private String questions_option_id;
    private String questions_subject_id;
    private String options;
    private String content;
    private Integer is_answer;
    private Integer status;
    private Integer sort;
    private Date create_time;
    private Date modify_time;

    public String getQuestions_option_id() {
        return questions_option_id;
    }
    public void setQuestions_option_id(String questions_option_id) {
        this.questions_option_id = questions_option_id == null ? null : questions_option_id.trim();
    }
    public String getQuestions_subject_id() {
        return questions_subject_id;
    }
    public void setQuestions_subject_id(String questions_subject_id) {
        this.questions_subject_id = questions_subject_id == null ? null : questions_subject_id.trim();
    }
    public String getOptions() {
        return options;
    }
    public void setOptions(String options) {
        this.options = options == null ? null : options.trim();
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }
    public Integer getIs_answer() {
        return is_answer;
    }
    public void setIs_answer(Integer is_answer) {
        this.is_answer = is_answer;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getSort() {
        return sort;
    }
    public void setSort(Integer sort) {
        this.sort = sort;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}