package com.yqh.shop.model;

import java.util.Date;

public class OperateQuestionsAnswer {

    private String questions_answer_id;
    private String user_id;
    private String questions_id;
    private Integer right_answer_count;
    private Integer answer_count;
    private Integer points;
    private Integer status;
    private Integer examine_status;
    private Date create_time;
    private Date modify_time;

    public String getQuestions_answer_id() {
        return questions_answer_id;
    }
    public void setQuestions_answer_id(String questions_answer_id) {
        this.questions_answer_id = questions_answer_id == null ? null : questions_answer_id.trim();
    }
    public String getUser_id() {
        return user_id;
    }
    public void setUser_id(String user_id) {
        this.user_id = user_id == null ? null : user_id.trim();
    }
    public String getQuestions_id() {
        return questions_id;
    }
    public void setQuestions_id(String questions_id) {
        this.questions_id = questions_id == null ? null : questions_id.trim();
    }
    public Integer getRight_answer_count() {
        return right_answer_count;
    }
    public void setRight_answer_count(Integer right_answer_count) {
        this.right_answer_count = right_answer_count;
    }
    public Integer getAnswer_count() {
        return answer_count;
    }
    public void setAnswer_count(Integer answer_count) {
        this.answer_count = answer_count;
    }
    public Integer getPoints() {
        return points;
    }
    public void setPoints(Integer points) {
        this.points = points;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getExamine_status() {
        return examine_status;
    }
    public void setExamine_status(Integer examine_status) {
        this.examine_status = examine_status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}