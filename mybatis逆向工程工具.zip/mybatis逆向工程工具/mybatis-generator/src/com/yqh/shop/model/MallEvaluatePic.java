package com.yqh.shop.model;

import java.util.Date;

public class MallEvaluatePic {

    private String evaluate_pic_id;
    private String evaluate_id;
    private String file_id;
    private String path;
    private Date create_time;
    private Date modify_time;

    public String getEvaluate_pic_id() {
        return evaluate_pic_id;
    }
    public void setEvaluate_pic_id(String evaluate_pic_id) {
        this.evaluate_pic_id = evaluate_pic_id == null ? null : evaluate_pic_id.trim();
    }
    public String getEvaluate_id() {
        return evaluate_id;
    }
    public void setEvaluate_id(String evaluate_id) {
        this.evaluate_id = evaluate_id == null ? null : evaluate_id.trim();
    }
    public String getFile_id() {
        return file_id;
    }
    public void setFile_id(String file_id) {
        this.file_id = file_id == null ? null : file_id.trim();
    }
    public String getPath() {
        return path;
    }
    public void setPath(String path) {
        this.path = path == null ? null : path.trim();
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}