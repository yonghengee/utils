package com.yqh.shop.model;

import java.util.Date;

public class MallGoodsTop {

    private String goods_top_id;
    private String goods_id;
    private String admin_id;
    private Date top_start_time;
    private Date top_end_time;
    private Integer sort;
    private Integer type;
    private Integer status;
    private Integer enables;
    private Date create_time;
    private Date modify_time;

    public String getGoods_top_id() {
        return goods_top_id;
    }
    public void setGoods_top_id(String goods_top_id) {
        this.goods_top_id = goods_top_id == null ? null : goods_top_id.trim();
    }
    public String getGoods_id() {
        return goods_id;
    }
    public void setGoods_id(String goods_id) {
        this.goods_id = goods_id == null ? null : goods_id.trim();
    }
    public String getAdmin_id() {
        return admin_id;
    }
    public void setAdmin_id(String admin_id) {
        this.admin_id = admin_id == null ? null : admin_id.trim();
    }
    public Date getTop_start_time() {
        return top_start_time;
    }
    public void setTop_start_time(Date top_start_time) {
        this.top_start_time = top_start_time;
    }
    public Date getTop_end_time() {
        return top_end_time;
    }
    public void setTop_end_time(Date top_end_time) {
        this.top_end_time = top_end_time;
    }
    public Integer getSort() {
        return sort;
    }
    public void setSort(Integer sort) {
        this.sort = sort;
    }
    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getEnables() {
        return enables;
    }
    public void setEnables(Integer enables) {
        this.enables = enables;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}