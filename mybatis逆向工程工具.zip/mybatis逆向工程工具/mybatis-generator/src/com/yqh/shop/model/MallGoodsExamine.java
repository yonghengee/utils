package com.yqh.shop.model;

import java.util.Date;

public class MallGoodsExamine {

    private String goods_examine_id;
    private String goods_id;
    private String admin_id;
    private String described;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getGoods_examine_id() {
        return goods_examine_id;
    }
    public void setGoods_examine_id(String goods_examine_id) {
        this.goods_examine_id = goods_examine_id == null ? null : goods_examine_id.trim();
    }
    public String getGoods_id() {
        return goods_id;
    }
    public void setGoods_id(String goods_id) {
        this.goods_id = goods_id == null ? null : goods_id.trim();
    }
    public String getAdmin_id() {
        return admin_id;
    }
    public void setAdmin_id(String admin_id) {
        this.admin_id = admin_id == null ? null : admin_id.trim();
    }
    public String getDescribed() {
        return described;
    }
    public void setDescribed(String described) {
        this.described = described == null ? null : described.trim();
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}