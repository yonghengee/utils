package com.yqh.shop.model;

import java.util.Date;

public class MallTypeParam {

    private Integer param_id;
    private Integer goods_type_id;
    private String name;
    private Integer is_multi;
    private Integer is_must;
    private Integer is_search;
    private Integer is_sku;
    private Integer is_key;
    private Integer is_input;
    private Integer is_enum;
    private Integer is_color;
    private Integer is_alis;
    private Integer sort;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public Integer getParam_id() {
        return param_id;
    }
    public void setParam_id(Integer param_id) {
        this.param_id = param_id;
    }
    public Integer getGoods_type_id() {
        return goods_type_id;
    }
    public void setGoods_type_id(Integer goods_type_id) {
        this.goods_type_id = goods_type_id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }
    public Integer getIs_multi() {
        return is_multi;
    }
    public void setIs_multi(Integer is_multi) {
        this.is_multi = is_multi;
    }
    public Integer getIs_must() {
        return is_must;
    }
    public void setIs_must(Integer is_must) {
        this.is_must = is_must;
    }
    public Integer getIs_search() {
        return is_search;
    }
    public void setIs_search(Integer is_search) {
        this.is_search = is_search;
    }
    public Integer getIs_sku() {
        return is_sku;
    }
    public void setIs_sku(Integer is_sku) {
        this.is_sku = is_sku;
    }
    public Integer getIs_key() {
        return is_key;
    }
    public void setIs_key(Integer is_key) {
        this.is_key = is_key;
    }
    public Integer getIs_input() {
        return is_input;
    }
    public void setIs_input(Integer is_input) {
        this.is_input = is_input;
    }
    public Integer getIs_enum() {
        return is_enum;
    }
    public void setIs_enum(Integer is_enum) {
        this.is_enum = is_enum;
    }
    public Integer getIs_color() {
        return is_color;
    }
    public void setIs_color(Integer is_color) {
        this.is_color = is_color;
    }
    public Integer getIs_alis() {
        return is_alis;
    }
    public void setIs_alis(Integer is_alis) {
        this.is_alis = is_alis;
    }
    public Integer getSort() {
        return sort;
    }
    public void setSort(Integer sort) {
        this.sort = sort;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}