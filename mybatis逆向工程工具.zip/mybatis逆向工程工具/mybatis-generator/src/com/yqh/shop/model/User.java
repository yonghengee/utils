package com.yqh.shop.model;

import java.util.Date;

public class User {

    private String user_id;
    private String region_id;
    private String region_name;
    private String photo_url;
    private String user_name;
    private String nick_name;
    private String mobile;
    private String password;
    private String open_id;
    private String chat_account;
    private Integer status;
    private Integer enables;
    private Integer apply_status;
    private String remark;
    private Date last_login;
    private Date create_time;
    private Date modify_time;

    public String getUser_id() {
        return user_id;
    }
    public void setUser_id(String user_id) {
        this.user_id = user_id == null ? null : user_id.trim();
    }
    public String getRegion_id() {
        return region_id;
    }
    public void setRegion_id(String region_id) {
        this.region_id = region_id == null ? null : region_id.trim();
    }
    public String getRegion_name() {
        return region_name;
    }
    public void setRegion_name(String region_name) {
        this.region_name = region_name == null ? null : region_name.trim();
    }
    public String getPhoto_url() {
        return photo_url;
    }
    public void setPhoto_url(String photo_url) {
        this.photo_url = photo_url == null ? null : photo_url.trim();
    }
    public String getUser_name() {
        return user_name;
    }
    public void setUser_name(String user_name) {
        this.user_name = user_name == null ? null : user_name.trim();
    }
    public String getNick_name() {
        return nick_name;
    }
    public void setNick_name(String nick_name) {
        this.nick_name = nick_name == null ? null : nick_name.trim();
    }
    public String getMobile() {
        return mobile;
    }
    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }
    public String getOpen_id() {
        return open_id;
    }
    public void setOpen_id(String open_id) {
        this.open_id = open_id == null ? null : open_id.trim();
    }
    public String getChat_account() {
        return chat_account;
    }
    public void setChat_account(String chat_account) {
        this.chat_account = chat_account == null ? null : chat_account.trim();
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Integer getEnables() {
        return enables;
    }
    public void setEnables(Integer enables) {
        this.enables = enables;
    }
    public Integer getApply_status() {
        return apply_status;
    }
    public void setApply_status(Integer apply_status) {
        this.apply_status = apply_status;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark == null ? null : remark.trim();
    }
    public Date getLast_login() {
        return last_login;
    }
    public void setLast_login(Date last_login) {
        this.last_login = last_login;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}