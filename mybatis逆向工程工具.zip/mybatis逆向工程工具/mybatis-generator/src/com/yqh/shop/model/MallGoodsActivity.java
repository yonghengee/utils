package com.yqh.shop.model;

import java.util.Date;

public class MallGoodsActivity {

    private String activity_id;
    private String sn;
    private String name;
    private Integer on_sale;
    private Date start_time;
    private Date end_time;
    private Integer is_coupon;
    private Integer join_num;
    private Integer sort;
    private Integer status;
    private Date create_time;
    private Date modify_time;

    public String getActivity_id() {
        return activity_id;
    }
    public void setActivity_id(String activity_id) {
        this.activity_id = activity_id == null ? null : activity_id.trim();
    }
    public String getSn() {
        return sn;
    }
    public void setSn(String sn) {
        this.sn = sn == null ? null : sn.trim();
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }
    public Integer getOn_sale() {
        return on_sale;
    }
    public void setOn_sale(Integer on_sale) {
        this.on_sale = on_sale;
    }
    public Date getStart_time() {
        return start_time;
    }
    public void setStart_time(Date start_time) {
        this.start_time = start_time;
    }
    public Date getEnd_time() {
        return end_time;
    }
    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }
    public Integer getIs_coupon() {
        return is_coupon;
    }
    public void setIs_coupon(Integer is_coupon) {
        this.is_coupon = is_coupon;
    }
    public Integer getJoin_num() {
        return join_num;
    }
    public void setJoin_num(Integer join_num) {
        this.join_num = join_num;
    }
    public Integer getSort() {
        return sort;
    }
    public void setSort(Integer sort) {
        this.sort = sort;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public Date getCreate_time() {
        return create_time;
    }
    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }
    public Date getModify_time() {
        return modify_time;
    }
    public void setModify_time(Date modify_time) {
        this.modify_time = modify_time;
    }
}