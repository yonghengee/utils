package com.yqh.shop.dao;

import java.util.List;
import java.util.Map;
import org.apache.ibatis.annotations.Param;

public interface OperateRecruitTopDao {
    List<Map<String, Object>> select(@Param("wheres") Map<String, Object> wheres, @Param("selects") List<String> selects, @Param("orders") List<String> orders);

    long select_count(@Param("wheres") Map<String, Object> wheres);

    int insert(Map<String, Object> dataMap);

    int insertSelective(Map<String, Object> dataMap);

    int update(@Param("wheres") Map<String, Object> wheres, @Param("datas") Map<String, Object> dataMap);

    int delete(Map<String, Object> dataMap);

    int batchDelete(List<String> list);
}